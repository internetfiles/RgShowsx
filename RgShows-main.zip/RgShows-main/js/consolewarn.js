console.log('%cCongrats you managed to open dev tabs 🎉', 'color: red; font-size: 30px; font-weight: bold;');
console.log('%cWell, you can join us too, join our discord https://discord.gg/bosskingdom-comeback-1090560322760347649 ✨', 'font-size: 18px;');
console.log('%cSub my yt too  https://www.youtube.com/c/@ItzRishabBoss 😳', 'font-size: 18px;');
console.log('%cHere my github : https://github.com/RISHAB-CREATOR 👀', 'font-size: 18px;');
console.log('%cBye Dude, have fun with inspecting the codes, Happy Coding! 😎', 'font-size: 18px;');
